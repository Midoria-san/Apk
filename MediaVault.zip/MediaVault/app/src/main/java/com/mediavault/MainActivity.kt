package com.mediavault

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import android.os.Build as B

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private val openId = mutableStateOf<Long?>(null)

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)

        setContent {
            AppTheme { AppNav(vm, openId) }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        val id = i?.getLongExtra("openMediaId", -1L) ?: -1L
        if (id > 0) openId.value = id
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        B.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun AppNav(vm: MainViewModel, openId: MutableState<Long?>) {
    val nav = rememberNavController()

    fun open(e: MediaEntry) =
        nav.navigate(if (e.type == MediaType.BOOK) "pdf/${e.id}" else "player/${e.id}")

    LaunchedEffect(openId.value) {
        val id = openId.value ?: return@LaunchedEffect
        val e = vm.getMedia(id)
        openId.value = null
        if (e != null) open(e)
    }

    NavHost(nav, startDestination = "home") {
        composable("home") {
            HomeScreen(
                vm,
                onLevel = { nav.navigate("level/$it") },
                onAlarms = { nav.navigate("alarms") },
                onPlayer = { nav.navigate("player/$it") }
            )
        }
        composable("level/{level}", arguments = listOf(navArgument("level") { type = NavType.IntType })) {
            LevelScreen(vm, it.arguments!!.getInt("level"), onBack = { nav.popBackStack() }, onOpen = { e -> open(e) })
        }
        composable("player/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) {
            PlayerScreen(vm, it.arguments!!.getLong("id"), onBack = { nav.popBackStack() })
        }
        composable("pdf/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) {
            PdfScreen(vm, it.arguments!!.getLong("id"), onBack = { nav.popBackStack() })
        }
        composable("alarms") {
            AlarmsScreen(vm, onBack = { nav.popBackStack() })
        }
    }
}
