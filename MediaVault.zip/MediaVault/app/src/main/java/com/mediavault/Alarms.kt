package com.mediavault

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

object AlarmScheduler {

    fun nextTrigger(a: AlarmEntry): Long {
        val now = Calendar.getInstance()
        for (offset in 0..7) {
            val c = now.clone() as Calendar
            c.add(Calendar.DAY_OF_YEAR, offset)
            c.set(Calendar.HOUR_OF_DAY, a.hour)
            c.set(Calendar.MINUTE, a.minute)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            if (c.timeInMillis <= now.timeInMillis) continue
            val bit = 1 shl (c.get(Calendar.DAY_OF_WEEK) - 1)
            if (a.daysMask == 0 || (a.daysMask and bit) != 0) return c.timeInMillis
        }
        return now.timeInMillis + 24L * 3600 * 1000
    }

    private fun pending(ctx: Context, id: Long): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, id.toInt(),
            Intent(ctx, AlarmReceiver::class.java).putExtra("alarmId", id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** Schedules with setAlarmClock (no special permission needed, fires in Doze). Returns trigger time. */
    fun schedule(ctx: Context, a: AlarmEntry): Long {
        val t = nextTrigger(a)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(t, show), pending(ctx, a.id))
        return t
    }

    fun cancel(ctx: Context, id: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(ctx, id))
    }
}

class AlarmReceiver : BroadcastReceiver() {
    @SuppressLint("MissingPermission")
    override fun onReceive(context: Context, intent: Intent) {
        val ctx = context.applicationContext
        val id = intent.getLongExtra("alarmId", -1)
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.get(ctx)
                val alarm = db.alarmDao().get(id) ?: return@launch
                if (!alarm.enabled) return@launch
                val media = db.mediaDao().get(alarm.mediaId)

                if (media != null) {
                    if (media.type == MediaType.BOOK) {
                        Notif.ensureChannels(ctx)
                        val open = Intent(ctx, MainActivity::class.java)
                            .putExtra("openMediaId", media.id)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        val pi = PendingIntent.getActivity(
                            ctx, media.id.toInt(), open,
                            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                        )
                        val n = NotificationCompat.Builder(ctx, Notif.CH_ALARM)
                            .setSmallIcon(R.drawable.ic_stat)
                            .setContentTitle("Time to read")
                            .setContentText(media.title)
                            .setContentIntent(pi)
                            .setAutoCancel(true)
                            .setCategory(NotificationCompat.CATEGORY_ALARM)
                            .build()
                        try { NotificationManagerCompat.from(ctx).notify(10_000 + media.id.toInt(), n) }
                        catch (_: SecurityException) {}
                    } else {
                        val svc = Intent(ctx, PlaybackService::class.java).apply {
                            action = PlaybackService.ACTION_ALARM_PLAY
                            putExtra(PlaybackService.EXTRA_ID, media.id)
                            putExtra(PlaybackService.EXTRA_URI, media.uri)
                            putExtra(PlaybackService.EXTRA_TITLE, media.title)
                            putExtra(PlaybackService.EXTRA_POS, media.lastPosition)
                        }
                        ContextCompat.startForegroundService(ctx, svc)
                    }
                }

                if (alarm.daysMask != 0) {
                    db.alarmDao().update(alarm.copy(triggerAt = AlarmScheduler.schedule(ctx, alarm)))
                } else {
                    db.alarmDao().update(alarm.copy(enabled = false))
                }
            } finally {
                pending.finish()
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val ctx = context.applicationContext
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = AppDatabase.get(ctx).alarmDao()
                val now = System.currentTimeMillis()
                dao.allNow().filter { it.enabled }.forEach { a ->
                    if (a.daysMask == 0 && a.triggerAt in 1 until now) {
                        dao.update(a.copy(enabled = false)) // missed while off
                    } else {
                        AlarmScheduler.schedule(ctx, a)
                    }
                }
            } finally {
                pending.finish()
            }
        }
    }
}
