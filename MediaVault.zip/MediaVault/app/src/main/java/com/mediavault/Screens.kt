@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.mediavault

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.DialogProperties
import androidx.media3.common.Player
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.withContext

val ROMAN = listOf("I", "II", "III", "IV", "V", "VI")

private fun iconFor(t: MediaType) = when (t) {
    MediaType.VIDEO -> Icons.Default.Movie
    MediaType.AUDIO -> Icons.Default.Audiotrack
    MediaType.BOOK -> Icons.Default.Book
}

private fun summary(items: List<MediaEntry>): String {
    if (items.isEmpty()) return "Empty"
    return MediaType.entries.mapNotNull { t ->
        val n = items.count { it.type == t }
        if (n == 0) null else "$n ${t.label.lowercase()}"
    }.joinToString(" · ")
}

private fun timeText(h: Int, m: Int): String {
    val h12 = if (h % 12 == 0) 12 else h % 12
    return "%d:%02d %s".format(h12, m, if (h < 12) "AM" else "PM")
}

private val DAY_NAMES = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")

private fun daysText(mask: Int): String = when (mask) {
    0 -> "Once"
    127 -> "Every day"
    else -> DAY_NAMES.filterIndexed { i, _ -> (mask and (1 shl i)) != 0 }.joinToString(", ")
}

// ===================== HOME =====================

@Composable
fun HomeScreen(vm: MainViewModel, onLevel: (Int) -> Unit, onAlarms: () -> Unit, onPlayer: (Long) -> Unit) {
    val media by vm.media.collectAsState()
    val now by vm.nowPlaying.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("MediaVault") },
                actions = {
                    IconButton(onClick = onAlarms) { Icon(Icons.Default.Alarm, "Alarms") }
                }
            )
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            now?.let { (id, title) ->
                item {
                    Card(
                        onClick = { onPlayer(id) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PlayCircle, null, Modifier.size(32.dp))
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("Now playing", style = MaterialTheme.typography.labelMedium)
                                Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
            items(6) { i ->
                val level = i + 1
                val inLevel = media.filter { it.level == level }
                Card(onClick = { onLevel(level) }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Folder, null, Modifier.size(36.dp))
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Level ${ROMAN[i]}", style = MaterialTheme.typography.titleLarge)
                            Text(summary(inLevel), style = MaterialTheme.typography.bodyMedium)
                        }
                        Icon(Icons.Default.ChevronRight, null)
                    }
                }
            }
        }
    }
}

// ===================== LEVEL =====================

@Composable
fun LevelScreen(vm: MainViewModel, level: Int, onBack: () -> Unit, onOpen: (MediaEntry) -> Unit) {
    val all by vm.media.collectAsState()
    var filter by remember { mutableStateOf<MediaType?>(null) }
    val items = all.filter { it.level == level && (filter == null || it.type == filter) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.addFiles(uris, level)
    }

    var renaming by remember { mutableStateOf<MediaEntry?>(null) }
    var moving by remember { mutableStateOf<MediaEntry?>(null) }
    var alarmFor by remember { mutableStateOf<MediaEntry?>(null) }
    var deleting by remember { mutableStateOf<MediaEntry?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Level ${ROMAN[level - 1]}") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { picker.launch(arrayOf("video/*", "audio/*", "application/pdf")) },
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text("Add files") }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(selected = filter == null, onClick = { filter = null }, label = { Text("All") })
                MediaType.entries.forEach { t ->
                    FilterChip(selected = filter == t, onClick = { filter = t }, label = { Text(t.label) })
                }
            }
            if (items.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Nothing here yet.\nTap “Add files”.", style = MaterialTheme.typography.bodyLarge)
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(bottom = 96.dp)) {
                    items(items, key = { it.id }) { e ->
                        var menu by remember { mutableStateOf(false) }
                        ListItem(
                            modifier = Modifier.clickable { onOpen(e) },
                            leadingContent = { Icon(iconFor(e.type), null) },
                            headlineContent = { Text(e.title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                            supportingContent = { Text(e.type.label.removeSuffix("s")) },
                            trailingContent = {
                                Box {
                                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menu") }
                                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                        DropdownMenuItem(
                                            text = { Text("Set alarm") },
                                            leadingIcon = { Icon(Icons.Default.AlarmAdd, null) },
                                            onClick = { menu = false; alarmFor = e })
                                        DropdownMenuItem(
                                            text = { Text("Rename") },
                                            leadingIcon = { Icon(Icons.Default.Edit, null) },
                                            onClick = { menu = false; renaming = e })
                                        DropdownMenuItem(
                                            text = { Text("Move to level…") },
                                            leadingIcon = { Icon(Icons.Default.Folder, null) },
                                            onClick = { menu = false; moving = e })
                                        DropdownMenuItem(
                                            text = { Text("Remove") },
                                            leadingIcon = { Icon(Icons.Default.Delete, null) },
                                            onClick = { menu = false; deleting = e })
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    renaming?.let { e ->
        var text by remember(e.id) { mutableStateOf(e.title) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Rename") },
            text = { OutlinedTextField(text, { text = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { vm.rename(e, text); renaming = null }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Cancel") } }
        )
    }

    moving?.let { e ->
        AlertDialog(
            onDismissRequest = { moving = null },
            title = { Text("Move to level") },
            text = {
                Column {
                    ROMAN.forEachIndexed { i, r ->
                        TextButton(
                            onClick = { vm.move(e, i + 1); moving = null },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Level $r" + if (i + 1 == e.level) "  (current)" else "") }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { moving = null }) { Text("Cancel") } }
        )
    }

    deleting?.let { e ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Remove from catalog?") },
            text = { Text("“${e.title}” and its alarms will be removed from the app. The file itself is not deleted.") },
            confirmButton = { TextButton(onClick = { vm.delete(e); deleting = null }) { Text("Remove") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }

    alarmFor?.let { e ->
        AlarmDialog(
            allMedia = all, preselected = e, onDismiss = { alarmFor = null },
            onSave = { id, h, m, mask -> vm.addAlarm(id, h, m, mask); alarmFor = null }
        )
    }
}

// ===================== ALARMS =====================

@Composable
fun AlarmDialog(
    allMedia: List<MediaEntry>,
    preselected: MediaEntry?,
    onDismiss: () -> Unit,
    onSave: (mediaId: Long, hour: Int, minute: Int, mask: Int) -> Unit
) {
    var chosen by remember { mutableStateOf(preselected ?: allMedia.firstOrNull()) }
    var menu by remember { mutableStateOf(false) }
    val tp = rememberTimePickerState(initialHour = 7, initialMinute = 0, is24Hour = false)
    var mask by remember { mutableIntStateOf(0) }
    val letters = listOf("S", "M", "T", "W", "T", "F", "S")

    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        title = { Text("Set alarm") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (preselected == null) {
                    Box {
                        OutlinedButton(onClick = { menu = true }) {
                            Text(chosen?.title ?: "Choose media", maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            allMedia.forEach { m ->
                                DropdownMenuItem(
                                    text = { Text(m.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                    leadingIcon = { Icon(iconFor(m.type), null) },
                                    onClick = { chosen = m; menu = false })
                            }
                        }
                    }
                } else {
                    Text(preselected.title, style = MaterialTheme.typography.titleMedium, maxLines = 2)
                }
                Spacer(Modifier.height(16.dp))
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { TimePicker(state = tp) }
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    letters.forEachIndexed { i, d ->
                        val on = (mask and (1 shl i)) != 0
                        Box(
                            Modifier.size(34.dp).clip(CircleShape)
                                .background(
                                    if (on) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .clickable { mask = mask xor (1 shl i) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                d,
                                color = if (on) MaterialTheme.colorScheme.onPrimary
                                else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    if (mask == 0) "No days selected: rings once." else "Repeats: ${daysText(mask)}",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        },
        confirmButton = {
            TextButton(enabled = chosen != null, onClick = { onSave(chosen!!.id, tp.hour, tp.minute, mask) }) {
                Text("Save")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun AlarmsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val alarms by vm.alarms.collectAsState()
    val media by vm.media.collectAsState()
    var adding by remember { mutableStateOf(false) }
    val ctx = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Alarms") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                }
            )
        },
        floatingActionButton = {
            if (media.isNotEmpty()) {
                ExtendedFloatingActionButton(
                    onClick = { adding = true },
                    icon = { Icon(Icons.Default.AlarmAdd, null) },
                    text = { Text("New alarm") }
                )
            }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(bottom = 96.dp)) {
            item {
                Card(Modifier.fillMaxWidth().padding(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(
                            "For alarms to fire reliably with the screen off, set this app's battery usage to Unrestricted.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        TextButton(onClick = {
                            ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                        }) { Text("Allow background running") }
                    }
                }
            }
            if (media.isEmpty()) {
                item { Text("Add some media first, then create alarms.", Modifier.padding(16.dp)) }
            } else if (alarms.isEmpty()) {
                item { Text("No alarms yet.", Modifier.padding(16.dp)) }
            }
            items(alarms, key = { it.id }) { a ->
                val m = media.firstOrNull { it.id == a.mediaId }
                ListItem(
                    headlineContent = {
                        Text(timeText(a.hour, a.minute), style = MaterialTheme.typography.headlineSmall)
                    },
                    supportingContent = {
                        Text("${m?.title ?: "Missing media"} · ${daysText(a.daysMask)}", maxLines = 2)
                    },
                    trailingContent = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(checked = a.enabled, onCheckedChange = { vm.setAlarmEnabled(a, it) })
                            IconButton(onClick = { vm.deleteAlarm(a) }) { Icon(Icons.Default.Delete, "Delete") }
                        }
                    }
                )
            }
        }
    }

    if (adding) {
        AlarmDialog(
            allMedia = media, preselected = null, onDismiss = { adding = false },
            onSave = { id, h, m, mask -> vm.addAlarm(id, h, m, mask); adding = false }
        )
    }
}

// ===================== PLAYER =====================

@Composable
fun PlayerScreen(vm: MainViewModel, id: Long, onBack: () -> Unit) {
    val entry = vm.media.collectAsState().value.firstOrNull { it.id == id }
    val controller by vm.controller.collectAsState()

    LaunchedEffect(controller, entry?.id) {
        val e = entry
        if (controller != null && e != null) vm.play(e)
    }

    DisposableEffect(id, controller) {
        onDispose {
            controller?.let {
                if (it.currentMediaItem?.mediaId == id.toString()) vm.savePosition(id, it.currentPosition)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(entry?.title ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                }
            )
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(Color.Black)) {
            val audioOnly = entry?.type == MediaType.AUDIO
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        useController = true
                        setShowNextButton(false)
                        setShowPreviousButton(false)
                    }
                },
                update = {
                    it.player = controller
                    it.controllerShowTimeoutMs = if (audioOnly) 0 else 3000
                    if (audioOnly) it.showController()
                },
                onRelease = { it.player = null }
            )
        }
    }
}

// ===================== PDF =====================

class PdfHolder(private val pfd: ParcelFileDescriptor) {
    private val renderer = PdfRenderer(pfd)
    @Volatile private var closed = false
    val pageCount: Int get() = renderer.pageCount

    fun render(i: Int): Bitmap? = synchronized(this) {
        if (closed) return@synchronized null
        try {
            val page = renderer.openPage(i)
            try {
                val w = 1400
                val h = (w.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(android.graphics.Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bmp
            } finally {
                page.close()
            }
        } catch (e: Exception) {
            null
        }
    }

    fun close() {
        synchronized(this) {
            closed = true
            runCatching { renderer.close() }
            runCatching { pfd.close() }
        }
    }
}

@Composable
fun PdfScreen(vm: MainViewModel, id: Long, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val entry = vm.media.collectAsState().value.firstOrNull { it.id == id }
    var holder by remember { mutableStateOf<PdfHolder?>(null) }
    var failed by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }

    val uriStr = entry?.uri
    LaunchedEffect(uriStr) {
        if (uriStr == null) return@LaunchedEffect
        val h = withContext(Dispatchers.IO) {
            runCatching {
                val pfd = ctx.contentResolver.openFileDescriptor(Uri.parse(uriStr), "r")!!
                PdfHolder(pfd)
            }.getOrNull()
        }
        if (h == null) failed = true else holder = h
    }
    DisposableEffect(holder) { onDispose { holder?.close() } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (title.isNotEmpty()) title else (entry?.title ?: ""),
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                }
            )
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
            val h = holder
            val startPage = entry?.lastPosition?.toInt() ?: 0
            when {
                failed -> Text("Couldn't open this PDF. Try removing and re-adding it.")
                h == null || h.pageCount == 0 -> CircularProgressIndicator()
                else -> {
                    val pager = rememberPagerState(
                        initialPage = startPage.coerceIn(0, h.pageCount - 1),
                        pageCount = { h.pageCount }
                    )
                    LaunchedEffect(pager) {
                        snapshotFlow { pager.currentPage }.collectLatest {
                            title = "${entry?.title ?: ""}  (${it + 1}/${h.pageCount})"
                            vm.savePosition(id, it.toLong())
                        }
                    }
                    HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { index ->
                        PdfPage(h, index)
                    }
                }
            }
        }
    }
}

@Composable
fun PdfPage(holder: PdfHolder, index: Int) {
    var bmp by remember(index) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(index) {
        bmp = withContext(Dispatchers.IO) { holder.render(index) }
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = "Page ${index + 1}",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Fit
            )
        } else {
            CircularProgressIndicator()
        }
    }
}
