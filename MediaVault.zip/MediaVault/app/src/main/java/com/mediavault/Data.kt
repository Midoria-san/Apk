package com.mediavault

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

enum class MediaType(val label: String) {
    VIDEO("Videos"), AUDIO("Audio"), BOOK("Books")
}

@Entity(tableName = "media")
data class MediaEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val type: MediaType,
    val uri: String,
    val level: Int,
    /** ms for video/audio, page index for books */
    val lastPosition: Long = 0
)

@Entity(tableName = "alarms")
data class AlarmEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val mediaId: Long,
    val hour: Int,
    val minute: Int,
    /** bit 0 = Sunday ... bit 6 = Saturday. 0 = one-time */
    val daysMask: Int = 0,
    val enabled: Boolean = true,
    val triggerAt: Long = 0
)

@Dao
interface MediaDao {
    @Query("SELECT * FROM media ORDER BY title COLLATE NOCASE")
    fun all(): Flow<List<MediaEntry>>

    @Query("SELECT * FROM media WHERE id = :id")
    suspend fun get(id: Long): MediaEntry?

    @Insert suspend fun insert(m: MediaEntry): Long

    @Query("DELETE FROM media WHERE id = :id") suspend fun delete(id: Long)
    @Query("UPDATE media SET lastPosition = :pos WHERE id = :id") suspend fun savePosition(id: Long, pos: Long)
    @Query("UPDATE media SET level = :level WHERE id = :id") suspend fun setLevel(id: Long, level: Int)
    @Query("UPDATE media SET title = :title WHERE id = :id") suspend fun rename(id: Long, title: String)
}

@Dao
interface AlarmDao {
    @Query("SELECT * FROM alarms ORDER BY hour, minute")
    fun all(): Flow<List<AlarmEntry>>

    @Query("SELECT * FROM alarms") suspend fun allNow(): List<AlarmEntry>
    @Query("SELECT * FROM alarms WHERE id = :id") suspend fun get(id: Long): AlarmEntry?

    @Insert suspend fun insert(a: AlarmEntry): Long
    @Update suspend fun update(a: AlarmEntry)
    @Query("DELETE FROM alarms WHERE id = :id") suspend fun delete(id: Long)
}

@Database(entities = [MediaEntry::class, AlarmEntry::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun mediaDao(): MediaDao
    abstract fun alarmDao(): AlarmDao

    companion object {
        @Volatile private var inst: AppDatabase? = null
        fun get(ctx: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "mediavault.db")
                .build().also { inst = it }
        }
    }
}
