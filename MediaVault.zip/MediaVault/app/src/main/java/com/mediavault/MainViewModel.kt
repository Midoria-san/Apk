package com.mediavault

import android.app.Application
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.guava.await
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(private val app: Application) : AndroidViewModel(app) {

    private val db = AppDatabase.get(app)

    val media: StateFlow<List<MediaEntry>> =
        db.mediaDao().all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val alarms: StateFlow<List<AlarmEntry>> =
        db.alarmDao().all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val controller = MutableStateFlow<MediaController?>(null)
    /** (mediaId, title) of what's currently loaded in the player service */
    val nowPlaying = MutableStateFlow<Pair<Long, String>?>(null)

    init {
        viewModelScope.launch {
            try {
                val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
                val c = MediaController.Builder(app, token).buildAsync().await()
                c.addListener(object : Player.Listener {
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = refresh(c)
                    override fun onPlaybackStateChanged(playbackState: Int) = refresh(c)
                })
                controller.value = c
                refresh(c)
            } catch (_: Exception) {
            }
        }
    }

    private fun refresh(c: MediaController) {
        val item = c.currentMediaItem
        val state = c.playbackState
        nowPlaying.value =
            if (item == null || state == Player.STATE_IDLE || state == Player.STATE_ENDED) null
            else item.mediaId.toLongOrNull()?.let { it to (item.mediaMetadata.title?.toString() ?: "") }
    }

    override fun onCleared() {
        controller.value?.release()
    }

    // ---------- playback ----------

    fun play(e: MediaEntry) {
        val c = controller.value ?: return
        if (c.currentMediaItem?.mediaId == e.id.toString()) {
            if (c.playbackState == Player.STATE_ENDED) c.seekTo(0)
            return
        }
        val uri = Uri.parse(e.uri)
        val item = MediaItem.Builder()
            .setMediaId(e.id.toString())
            .setUri(uri)
            .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(uri).build())
            .setMediaMetadata(MediaMetadata.Builder().setTitle(e.title).build())
            .build()
        c.setMediaItem(item, e.lastPosition)
        c.prepare()
        c.playWhenReady = true
    }

    fun savePosition(id: Long, pos: Long) {
        viewModelScope.launch(Dispatchers.IO) { db.mediaDao().savePosition(id, pos) }
    }

    suspend fun getMedia(id: Long): MediaEntry? = withContext(Dispatchers.IO) { db.mediaDao().get(id) }

    // ---------- catalog ----------

    fun addFiles(uris: List<Uri>, level: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val r = app.contentResolver
            for (u in uris) {
                try {
                    r.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
                val name = displayName(u)
                val type = detect(u, name) ?: continue
                db.mediaDao().insert(
                    MediaEntry(title = name.substringBeforeLast('.'), type = type, uri = u.toString(), level = level)
                )
            }
        }
    }

    private fun displayName(u: Uri): String {
        try {
            app.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: "Untitled"
            }
        } catch (_: Exception) {
        }
        return u.lastPathSegment ?: "Untitled"
    }

    private fun detect(u: Uri, name: String): MediaType? {
        val mime = app.contentResolver.getType(u) ?: ""
        return when {
            mime.startsWith("video/") -> MediaType.VIDEO
            mime.startsWith("audio/") -> MediaType.AUDIO
            mime == "application/pdf" -> MediaType.BOOK
            else -> when (name.substringAfterLast('.', "").lowercase()) {
                "mp4", "mkv", "webm", "avi", "mov", "3gp", "m4v" -> MediaType.VIDEO
                "mp3", "m4a", "aac", "wav", "ogg", "flac", "opus" -> MediaType.AUDIO
                "pdf" -> MediaType.BOOK
                else -> null
            }
        }
    }

    fun rename(e: MediaEntry, title: String) {
        if (title.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) { db.mediaDao().rename(e.id, title.trim()) }
    }

    fun move(e: MediaEntry, level: Int) {
        viewModelScope.launch(Dispatchers.IO) { db.mediaDao().setLevel(e.id, level) }
    }

    fun delete(e: MediaEntry) {
        controller.value?.let {
            if (it.currentMediaItem?.mediaId == e.id.toString()) {
                it.stop(); it.clearMediaItems()
            }
        }
        viewModelScope.launch(Dispatchers.IO) {
            alarms.value.filter { it.mediaId == e.id }.forEach {
                AlarmScheduler.cancel(app, it.id)
                db.alarmDao().delete(it.id)
            }
            db.mediaDao().delete(e.id)
        }
    }

    // ---------- alarms ----------

    fun addAlarm(mediaId: Long, hour: Int, minute: Int, mask: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val dao = db.alarmDao()
            var a = AlarmEntry(mediaId = mediaId, hour = hour, minute = minute, daysMask = mask)
            a = a.copy(id = dao.insert(a))
            dao.update(a.copy(triggerAt = AlarmScheduler.schedule(app, a)))
        }
    }

    fun setAlarmEnabled(a: AlarmEntry, enabled: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            if (enabled) {
                db.alarmDao().update(a.copy(enabled = true, triggerAt = AlarmScheduler.schedule(app, a)))
            } else {
                AlarmScheduler.cancel(app, a.id)
                db.alarmDao().update(a.copy(enabled = false))
            }
        }
    }

    fun deleteAlarm(a: AlarmEntry) {
        viewModelScope.launch(Dispatchers.IO) {
            AlarmScheduler.cancel(app, a.id)
            db.alarmDao().delete(a.id)
        }
    }
}
