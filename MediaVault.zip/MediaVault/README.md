# MediaVault

Catalog videos, audio and PDF books into Levels I-VI, play in the background, and schedule alarms that auto-start media.

## Build
Requirements: JDK 17, Android SDK (platform 34, build-tools 34), Gradle 8.7.

    gradle wrapper --gradle-version 8.7     # only if gradlew is missing
    ./gradlew assembleDebug                 # or: gradle assembleDebug

APK: app/build/outputs/apk/debug/app-debug.apk
(Or open in Android Studio -> Build -> Build APK(s). Or push to GitHub; the included workflow builds it.)

## Tips
- Allow notifications on first launch.
- Alarms screen -> "Allow background running" and set battery to Unrestricted, especially on Xiaomi/Samsung/Oppo/Huawei.
- Videos that start from an alarm play their audio with the screen off; open the app to see the picture.
- Books can't "play", so a book alarm shows a notification that opens the PDF at your last page.
